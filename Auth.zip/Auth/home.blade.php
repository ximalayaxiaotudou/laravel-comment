@extends('layouts.app')

@section('content')

<!-- 错误信息 -->
@include('shared.errors')

<h1>Home</h1>

@endsection